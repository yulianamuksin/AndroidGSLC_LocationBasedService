# Final Project Assignment (Personal)
# Yuliana Muksin 2201800091 LM01

Aplikasi untuk memesan makanan dengan menerapkan Location Based Service menggunakan Google Map Services dan menyimpan database secara local menggunakan SQLite. 

Aplikasi ini dapat di-install pada Android Device menggunakan Signed APK yang sudah di-published di link: https://github.com/yulianamuksin/Final-Project-Assignment

Untuk mengakses aplikasi ini pada Android Device, Langkah-langkah yang harus dilakukan adalah: 
1.	Download project dan Signed APK yang sudah di-published pada link akun Github diatas. 
2.	Download Signed APK yang ada dalam projek tersebut ke dalam Android Device dan lakukan instalasi aplikasi pada Android Device.
3.	Pastikan bahwa Settings (pengaturan) pada Android Device sudah mengizinkan download / instalasi aplikasi “from unknown developers”, sehingga aplikasi ini dapat di-install dengan baik pada Android device Anda. 
4.	Setelah aplikasi berhasil di-install pada Android Device, klik ikon aplikasi untuk menjalankan aplikasi.
5.	User HARUS MENGAKTIFKAN WIFI / DATA dan MENGAKTIFKAN GPS pada Android Device mereka agar aplikasi dapat berjalan dengan lancar.

